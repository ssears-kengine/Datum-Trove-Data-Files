#!/usr/bin/env python3
"""
Echo Recombiner (GUI) — with Force Assemble option
- Recombine files split into packets with a manifest.json
- Verifies each packet's SHA-256 and total file hash
- NEW: "Force Assemble" mode fills missing/corrupt packets with zero bytes
- Streaming (memory-efficient)
"""

import hashlib
import json
import mimetypes
import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import ttk

APP_TITLE = "Echo Recombiner — Packets (GUI-only)"
MANIFEST_NAME = "manifest.json"
BUF = 1 << 20  # 1 MiB

def sha256_path(path, bufsize=BUF):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            b = f.read(bufsize)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def guess_extension(original_name: str, mime: str) -> str:
    base, ext = os.path.splitext(original_name or "")
    if ext:
        return ext
    if mime:
        ext2 = mimetypes.guess_extension(mime)
        if ext2:
            return ext2
    return ""

def load_manifest(folder: str) -> dict:
    mpath = os.path.join(folder, MANIFEST_NAME)
    if not os.path.isfile(mpath):
        raise FileNotFoundError(f"manifest.json not found in:\n{folder}")
    with open(mpath, "r", encoding="utf-8") as f:
        m = json.load(f)
    for k in ("packet_count", "packets", "total_size", "sha256_total"):
        if k not in m:
            raise ValueError(f"Manifest missing key: {k}")
    if not isinstance(m["packets"], list) or not m["packets"]:
        raise ValueError("Manifest 'packets' list is empty.")
    return m

def verify_packets_strict(folder: str, manifest: dict, progress_cb=None):
    """Strict verification—raise on first problem."""
    pkts = sorted(manifest["packets"], key=lambda p: p["index"])
    n = len(pkts)
    total = 0
    for i, p in enumerate(pkts, 1):
        p_path = os.path.join(folder, p["filename"])
        if not os.path.isfile(p_path):
            raise FileNotFoundError(f"Missing packet file: {p['filename']}")
        if os.path.getsize(p_path) != int(p["length"]):
            raise ValueError(f"Length mismatch for {p['filename']}")
        digest = sha256_path(p_path)
        if digest != p["sha256"]:
            raise ValueError(f"SHA-256 mismatch for {p['filename']}")
        total += p["length"]
        if progress_cb: progress_cb(i, n)
    return total

def assemble_to_file(folder: str, manifest: dict, out_path: str,
                     progress_cb=None, force=False, logger=None):
    """
    Assemble to out_path.
    - strict mode: raises on missing/corrupt packets, enforces final hash
    - force mode: fills missing/corrupt packets with zeros and reports PARTIAL
    Returns (written_bytes, final_sha256_hex, partial_bool)
    """
    pkts = sorted(manifest["packets"], key=lambda p: p["index"])
    n = len(pkts)
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)

    h_total = hashlib.sha256()
    written = 0
    partial = False
    zero_buf = b"\x00" * BUF

    def log(msg):
        if logger: logger(msg)

    with open(out_path, "wb") as out:
        for i, p in enumerate(pkts, 1):
            p_path = os.path.join(folder, p["filename"])
            expected_len = int(p["length"])
            need_zero_fill = False
            stream_path = None

            if not os.path.isfile(p_path):
                if force:
                    need_zero_fill = True
                    partial = True
                    log(f"⚠️  Missing: {p['filename']} → filling {expected_len} bytes with zeros")
                else:
                    raise FileNotFoundError(f"Missing packet file: {p['filename']}")
            else:
                # in force mode we verify but don't fail hard; in strict we must match
                if os.path.getsize(p_path) != expected_len:
                    if force:
                        need_zero_fill = True
                        partial = True
                        log(f"⚠️  Length mismatch: {p['filename']} → zero fill {expected_len} bytes")
                    else:
                        raise ValueError(f"Length mismatch for {p['filename']}")
                else:
                    digest = sha256_path(p_path)
                    if digest != p["sha256"]:
                        if force:
                            need_zero_fill = True
                            partial = True
                            log(f"⚠️  SHA-256 mismatch: {p['filename']} → zero fill {expected_len} bytes")
                        else:
                            raise ValueError(f"SHA-256 mismatch for {p['filename']}")
                    else:
                        stream_path = p_path

            if need_zero_fill:
                remaining = expected_len
                while remaining > 0:
                    chunk = zero_buf if remaining >= len(zero_buf) else b"\x00" * remaining
                    out.write(chunk)
                    h_total.update(chunk)
                    written += len(chunk)
                    remaining -= len(chunk)
            else:
                with open(stream_path, "rb") as pf:
                    while True:
                        b = pf.read(BUF)
                        if not b:
                            break
                        out.write(b)
                        h_total.update(b)
                        written += len(b)

            if progress_cb: progress_cb(i, n)

    final_hex = h_total.hexdigest()

    # Final checks
    if not force:
        if written != int(manifest["total_size"]):
            raise ValueError(f"Total size mismatch. Wrote {written}, expected {manifest['total_size']}.")
        if final_hex != manifest["sha256_total"]:
            raise ValueError("Total SHA-256 mismatch after assembly.")
    else:
        # In force mode, just report discrepancies
        if written != int(manifest["total_size"]):
            partial = True
            log(f"ℹ️  Total size differs: wrote {written}, manifest {manifest['total_size']}")
        if final_hex != manifest["sha256_total"]:
            partial = True
            log("ℹ️  Final SHA-256 differs from manifest (partial reconstruction).")

    return written, final_hex, partial

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.minsize(780, 460)

        self.var_folder = tk.StringVar()
        self.var_out = tk.StringVar()
        self.var_status = tk.StringVar(value="Ready")
        self.var_autoext = tk.BooleanVar(value=True)
        self.var_force = tk.BooleanVar(value=False)  # NEW

        self._build_ui()

    def _build_ui(self):
        frm = ttk.Frame(self, padding=12)
        frm.pack(fill="both", expand=True)

        # Packet folder
        row = ttk.Frame(frm); row.pack(fill="x", pady=6)
        ttk.Label(row, text="Packet folder (with manifest.json):").pack(side="left")
        ttk.Entry(row, textvariable=self.var_folder).pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(row, text="Browse…", command=self.pick_folder).pack(side="left")

        # Output file
        row = ttk.Frame(frm); row.pack(fill="x", pady=6)
        ttk.Label(row, text="Output file:").pack(side="left")
        ttk.Entry(row, textvariable=self.var_out).pack(side="left", fill="x", expand=True, padx=6)
        ttk.Button(row, text="Choose…", command=self.pick_output).pack(side="left")

        # Options
        row = ttk.Frame(frm); row.pack(fill="x", pady=6)
        ttk.Checkbutton(row, text="Auto append extension from manifest", variable=self.var_autoext).pack(side="left")
        ttk.Checkbutton(row, text="Force Assemble (skip missing/corrupt packets)", variable=self.var_force).pack(side="left", padx=(12,0))
        ttk.Button(row, text="Verify Only", command=self.verify_only).pack(side="right", padx=(6,0))
        ttk.Button(row, text="Assemble", command=self.run_assemble).pack(side="right", padx=(6,0))
        ttk.Button(row, text="About", command=self.show_about).pack(side="right")

        # Progress + status
        self.pbar = ttk.Progressbar(frm, mode="determinate", maximum=100)
        self.pbar.pack(fill="x", pady=(12, 4))
        ttk.Label(frm, textvariable=self.var_status, foreground="#06c").pack(anchor="w")

        # Log
        self.log = tk.Text(frm, height=12, wrap="word")
        self.log.pack(fill="both", expand=True, pady=(8, 0))

    # ---- helpers

    def pick_folder(self):
        path = filedialog.askdirectory(title="Select packet folder")
        if path: self.var_folder.set(path)

    def pick_output(self):
        path = filedialog.asksaveasfilename(title="Save recombined file as")
        if path: self.var_out.set(path)

    def _update_progress(self, done, total):
        pct = int(done / total * 100) if total else 0
        self.pbar["value"] = pct
        self.var_status.set(f"Progress: {done}/{total} ({pct}%)")
        self.update_idletasks()

    def clear_progress(self, msg="Ready"):
        self.pbar["value"] = 0
        self.var_status.set(msg)

    def append_log(self, txt):
        self.log.insert("end", txt + "\n")
        self.log.see("end")

    def _load_manifest_checked(self):
        folder = self.var_folder.get().strip()
        if not folder or not os.path.isdir(folder):
            raise FileNotFoundError("Please select a valid packet folder.")
        m = load_manifest(folder)
        return folder, m

    # ---- actions

    def verify_only(self):
        self.clear_progress("Verifying packets…")
        try:
            folder, m = self._load_manifest_checked()
            # Strict verify even if "force" is checked—this is a diagnostic
            total = verify_packets_strict(folder, m, progress_cb=self._update_progress)
            self.append_log(f"✅ Verified {len(m['packets'])} packets, {total} bytes.")
            self.var_status.set("Verification complete.")
        except Exception as e:
            self.var_status.set("Verification failed.")
            messagebox.showerror("Verify", str(e))

    def run_assemble(self):
        self.clear_progress("Assembling…")
        try:
            folder, m = self._load_manifest_checked()
        except Exception as e:
            self.var_status.set("Error")
            messagebox.showerror("Manifest", str(e))
            return

        out_path = self.var_out.get().strip()
        if not out_path:
            base = os.path.splitext(m.get("original_filename") or "recombined")[0]
            ext = guess_extension(m.get("original_filename",""), m.get("mime_type","")) if self.var_autoext.get() else ""
            out_path = filedialog.asksaveasfilename(title="Save recombined file as",
                                                    initialfile=(base + ext) if ext else base)
            if not out_path:
                self.clear_progress("Canceled.")
                return
            self.var_out.set(out_path)
        else:
            if self.var_autoext.get() and not os.path.splitext(out_path)[1]:
                out_path = out_path + (guess_extension(m.get("original_filename",""), m.get("mime_type","")) or "")
                self.var_out.set(out_path)

        force = self.var_force.get()

        try:
            written, digest, partial = assemble_to_file(
                folder, m, out_path,
                progress_cb=self._update_progress,
                force=force,
                logger=self.append_log
            )
            flag = " (PARTIAL)" if partial else ""
            self.append_log(f"✅ Assembled {written} bytes to: {out_path}{flag}")
            self.append_log(f"Final SHA-256: {digest}{'  [DIFFERS FROM MANIFEST]' if partial else ''}")
            self.var_status.set("Assemble complete." + (" (partial)" if partial else ""))
            if partial:
                messagebox.showwarning("Complete (Partial)",
                                       "Assembly finished with missing/corrupt packets.\n"
                                       "Gaps were filled with zeros.\nThe result may be unusable or corrupted.")
            else:
                messagebox.showinfo("Complete", f"Recombined file saved:\n{out_path}")
        except Exception as e:
            self.var_status.set("Assemble failed.")
            messagebox.showerror("Assemble", str(e))

    def show_about(self):
        messagebox.showinfo(
            "About",
            "Echo Recombiner (GUI)\n"
            "• Reads manifest.json and packet_*.bin\n"
            "• Verifies SHA-256 for each packet and total\n"
            "• Force Assemble fills missing/corrupt packets with zeros (partial result)\n"
            "Knowledge Engine • Datum-Trove"
        )

if __name__ == "__main__":
    app = App()
    app.mainloop()
