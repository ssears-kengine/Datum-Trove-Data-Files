#!/usr/bin/env python3
"""
Stego Extract Only — PNG/WAV (Tk)
---------------------------------
A tiny GUI that **only extracts** embedded data from PNG or WAV files made
with the companion stego tool (same header format).

This version includes beginner-friendly comments and auto-detects several file types.

Features
- Detects and validates embedded payloads in .png or .wav (8/16-bit PCM)
- Integrity check via SHA-256 (OK/FAILED shown)
- Saves output to a chosen folder; auto-adds .txt for text payloads
- **Auto-detects payload type** (WAV, PNG, JPG, ZIP, PDF) from magic bytes
- Lightweight: Pillow is the only external dependency

Dependencies
    pip install Pillow

Usage
    python stego_extract_only.py

Notes
- This reader expects the header layout used by the original tool:
  MAGIC(5) + kind(1) + name_len(2) + payload_len(8) + sha256(32) + name + payload
- It does not support embedding or the Ghost Image mode—extraction only.
"""

import os
import hashlib
import traceback
import wave
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image

MAGIC = b"STEG1"  # header identifier used in both encoding and decoding

# --------------------------------------------------
# Bit and byte conversion helpers
# --------------------------------------------------
def bytes_needed_for_bits(n_bits: int) -> int:
    return (n_bits + 7) // 8

def bytes_from_bits(bits_iter, n_bits: int) -> bytes:
    out = bytearray(bytes_needed_for_bits(n_bits))
    for bit_idx in range(n_bits):
        b_idx = bit_idx // 8
        shift = 7 - (bit_idx % 8)
        out[b_idx] |= (next(bits_iter) & 1) << shift
    return bytes(out)

# --------------------------------------------------
# Header unpacking logic
# --------------------------------------------------
def unpack_header(blob: bytes):
    if len(blob) < 5 + 1 + 2 + 8 + 32:
        raise ValueError("Embedded data truncated.")
    if blob[:5] != MAGIC:
        raise ValueError("No embedded data header found.")
    off = 5
    kind = blob[off]; off += 1
    name_len = int.from_bytes(blob[off:off + 2], 'big'); off += 2
    payload_len = int.from_bytes(blob[off:off + 8], 'big'); off += 8
    sha = blob[off:off + 32]; off += 32
    if len(blob) < off + name_len + payload_len:
        raise ValueError("Embedded data incomplete.")
    name = blob[off:off + name_len].decode('utf-8', 'replace'); off += name_len
    payload = blob[off:off + payload_len]
    return kind, name, payload, sha

# --------------------------------------------------
# PNG extraction
# --------------------------------------------------
def _png_bytearray_and_meta(path: str):
    img = Image.open(path).convert("RGBA")
    w, h = img.size
    data = bytearray(img.tobytes())
    return data, (w, h), "RGBA"

def png_extract(stego_path: str) -> bytes:
    buf, _, _ = _png_bytearray_and_meta(stego_path)
    fixed_len = 5 + 1 + 2 + 8 + 32
    if len(buf) < fixed_len * 8:
        raise ValueError("Image too small for header.")

    def gen():
        for b in buf:
            yield b & 1

    fixed = bytes_from_bits(gen(), fixed_len * 8)
    if fixed[:5] != MAGIC:
        raise ValueError("No embedded data header found.")
    name_len = int.from_bytes(fixed[6:8], 'big')
    payload_len = int.from_bytes(fixed[8:16], 'big')
    total_len = fixed_len + name_len + payload_len
    if len(buf) < total_len * 8:
        raise ValueError("Truncated embedded data in image.")

    full = bytes_from_bits(gen(), total_len * 8)
    return full

# --------------------------------------------------
# WAV extraction
# --------------------------------------------------
def wav_extract(stego_path: str) -> bytes:
    with wave.open(stego_path, 'rb') as wf:
        n_channels = wf.getnchannels()
        sampwidth = wf.getsampwidth()
        n_frames = wf.getnframes()
        raw = bytearray(wf.readframes(n_frames))

    def gen():
        if sampwidth == 1:
            for b in raw:
                yield b & 1
        elif sampwidth == 2:
            total_samples = n_channels * n_frames
            for sample_idx in range(total_samples):
                yield raw[sample_idx * 2] & 1
        else:
            raise ValueError("Only 8-bit or 16-bit PCM supported.")

    fixed_len = 5 + 1 + 2 + 8 + 32
    fixed = bytes_from_bits(gen(), fixed_len * 8)
    if fixed[:5] != MAGIC:
        raise ValueError("No embedded data header found.")
    name_len = int.from_bytes(fixed[6:8], 'big')
    payload_len = int.from_bytes(fixed[8:16], 'big')
    total_len = fixed_len + name_len + payload_len
    full = bytes_from_bits(gen(), total_len * 8)
    return full

# --------------------------------------------------
# File type detection via magic bytes
# --------------------------------------------------
PNG_SIG = b"\x89PNG\r\n\x1a\n"
JPG_SIG = b"\xff\xd8\xff"
ZIP_SIG = b"PK\x03\x04"
PDF_SIG = b"%PDF-"

def detect_payload_ext(payload: bytes) -> str:
    if len(payload) >= 12 and payload[:4] == b"RIFF" and payload[8:12] == b"WAVE":
        return ".wav"
    if payload.startswith(PNG_SIG):
        return ".png"
    if payload.startswith(JPG_SIG):
        return ".jpg"
    if payload.startswith(ZIP_SIG):
        return ".zip"
    if payload.startswith(PDF_SIG):
        return ".pdf"
    return ""

# --------------------------------------------------
# Dispatcher
# --------------------------------------------------
def extract_logic(stego_path: str):
    ext = os.path.splitext(stego_path)[1].lower()
    if ext == '.png':
        full = png_extract(stego_path)
    elif ext == '.wav':
        full = wav_extract(stego_path)
    else:
        raise ValueError("Unsupported file type (use PNG or WAV).")
    return unpack_header(full)

# --------------------------------------------------
# Tkinter GUI
# --------------------------------------------------
class ExtractApp(ttk.Frame):
    def __init__(self, master):
        super().__init__(master, padding=10)
        self.pack(fill="both", expand=True)
        master.title("Echo's Stego Extract Tool — PNG/WAV")
        self._build()

    def _build(self):
        row = 0
        ttk.Label(self, text="Stego PNG/WAV:").grid(row=row, column=0, sticky="w")
        self.in_var = tk.StringVar()
        self.in_entry = ttk.Entry(self, textvariable=self.in_var, width=60)
        self.in_entry.grid(row=row, column=1, sticky="ew")
        ttk.Button(self, text="Browse", command=self._browse_in).grid(row=row, column=2, sticky="e")
        self.columnconfigure(1, weight=1)
        row += 1

        ttk.Label(self, text="Extract to folder:").grid(row=row, column=0, sticky="w")
        self.dir_var = tk.StringVar()
        self.dir_entry = ttk.Entry(self, textvariable=self.dir_var)
        self.dir_entry.grid(row=row, column=1, sticky="ew")
        ttk.Button(self, text="Choose Folder", command=self._browse_dir).grid(row=row, column=2, sticky="e")
        row += 1

        self.status = tk.StringVar()
        ttk.Label(self, textvariable=self.status, wraplength=900, justify="left").grid(row=row, column=0, columnspan=3, sticky="w", pady=(6,6))
        row += 1

        btns = ttk.Frame(self)
        btns.grid(row=row, column=0, columnspan=3, sticky="w")
        ttk.Button(btns, text="Extract", command=self._do_extract).pack(side="left")
        ttk.Button(btns, text="Quit", command=self._quit).pack(side="left", padx=(8,0))

    def _browse_in(self):
        path = filedialog.askopenfilename(title="Select stego PNG or WAV", filetypes=[("PNG/WAV", "*.png;*.wav")])
        if path:
            self.in_var.set(path)

    def _browse_dir(self):
        path = filedialog.askdirectory(title="Choose extract folder")
        if path:
            self.dir_var.set(path)

    def _quit(self):
        self.winfo_toplevel().destroy()

    def _do_extract(self):
        try:
            stego = self.in_var.get().strip()
            if not stego:
                raise ValueError("Select a PNG or WAV file to extract.")
            out_dir = self.dir_var.get().strip() or os.path.dirname(stego) or os.getcwd()

            kind, name, payload, sha = extract_logic(stego)
            ok = hashlib.sha256(payload).digest() == sha

            base, ext = os.path.splitext(name)
            detected_ext = detect_payload_ext(payload) if kind != 0 else ""

            if kind == 0:
                if not ext:
                    name = (base or "message") + ".txt"
            else:
                if not ext:
                    if detected_ext:
                        name = (base or "payload") + detected_ext
                    else:
                        parent_ext = os.path.splitext(stego)[1].lower()
                        name = (base or "payload") + (parent_ext if parent_ext in (".wav", ".png") else ".bin")

            out_path = os.path.join(out_dir, name)
            with open(out_path, 'wb') as f:
                f.write(payload)

            preview = ""
            if kind == 0:
                try:
                    preview_text = payload.decode('utf-8')[:1000]
                    if preview_text:
                        preview = "\n\nPreview (first 1000 chars):\n" + preview_text
                except Exception:
                    pass

            type_note = f" (detected {detected_ext})" if detected_ext else ""
            self.status.set(
                f"Extracted {'TEXT' if kind == 0 else 'FILE'} ({name}) → {out_path}{type_note}\n"
                f"Integrity: {'OK' if ok else 'FAILED'}; Size: {len(payload)} bytes{preview}"
            )
        except Exception as e:
            self.status.set(f"Error: {e}")
            traceback.print_exc()
            messagebox.showerror("Extract error", str(e))

# --------------------------------------------------
# Program entry
# --------------------------------------------------
def main():
    root = tk.Tk()
    app = ExtractApp(root)
    root.geometry("860x380")
    root.mainloop()

if __name__ == "__main__":
    main()
